getwd()
setwd("C:/Users/IT24101284/Desktop/IT24101284_ PS_Labsheet-05")
Delivery_Times<-read.table("Exercise - Lab 05.txt",header=TRUE,sep=",")

fix(Delivery_Times)

attach(Delivery_Times)

str(Delivery_Times)

hist(Delivery_Times$Delivery_Time_.minutes., 
     breaks = seq(20, 70, by = 5), 
     right = TRUE, 
     main = "Histogram of Delivery Times", 
     xlab = "Delivery Time", 
     ylab = "Frequency", 
     col = "lightblue")


delivery_times_freq <- hist(Delivery_Times$Delivery_Time_.minutes., 
                            breaks = seq(20, 70, by = 5), 
                            right = TRUE, 
                            plot = FALSE)


cumulative_freq <- cumsum(delivery_times_freq$counts)


plot(delivery_times_freq$mids, cumulative_freq, type = "o", 
     col = "blue", 
     xlab = "Delivery Time", 
     ylab = "Cumulative Frequency", 
     main = "Cumulative Frequency Polygon (Ogive)")
