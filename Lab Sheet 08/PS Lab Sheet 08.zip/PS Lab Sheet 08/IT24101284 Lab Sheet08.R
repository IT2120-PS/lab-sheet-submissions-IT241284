setwd("C:\\Users\\User\\OneDrive\\Desktop\\PS Lab Sheet 08")

data <- read.table("Exercise - LaptopsWeights.txt",header=TRUE)
fix(data)
attach(data)

# Question 01
pop_mean_laptop <-mean(Weight.kg.)
pop_sd_laptop <-sd(Weight.kg.)

# Question 02
samples_laptop <- c()
n_laptop <- c()

for (i in 1:25){
  s_laptop <- sample(Weight.kg.,6,replace = TRUE)
  samples_laptop <-cbind(samples_laptop,s_laptop)
  n_laptop <-c(n_laptop,paste('S',i))
}

colnames(samples_laptop) =n_laptop

s.mean_laptop <- apply(samples_laptop,2,mean)
s.sd_laptop <- apply(samples_laptop,2,sd)



# Question 03
mean_of_s_means <- mean(s.mean_laptop)
sd_of_s_means <- sd(s.mean_laptop)

pop_mean_laptop
mean_of_s_means

pop_sd_laptop
sd_of_s_means
