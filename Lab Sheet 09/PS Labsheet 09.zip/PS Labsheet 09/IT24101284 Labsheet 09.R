setwd("C:\\Users\\User\\OneDrive\\Desktop\\PS Labsheet 09")

x<-rnorm(25,mean=45,sd=2)
t.test(x,mu=46,alternative="less")
