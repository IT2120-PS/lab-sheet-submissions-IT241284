setwd("C:\\Users\\User\\OneDrive\\Desktop\\PS_LabSheet_06")
nE1 <- 50
pE1 <- 0.85

# (i) Distribution
cat("Ex1 (i) -> Distribution: X ~ Binomial(n=50, p=0.85)\n\n")

# (ii) Probability ≥ 47 students pass
ex1_ii <- 1 - pbinom(46, size=nE1, prob=pE1)
cat("Ex1 (ii) P(X >= 47) =", ex1_ii, "\n\n")



# Call center: 12 calls/hour
# X ~ Poisson(lambda = 12)

lambdaE2 <- 12

# (i) Random variable
cat("Ex2 (i) -> Random variable: Number of calls per hour\n\n")

# (ii) Distribution
cat("Ex2 (ii) -> Distribution: X ~ Poisson(lambda = 12)\n\n")

# (iii) Probability exactly 15 calls
ex2_iii <- dpois(15, lambda=lambdaE2)
cat("Ex2 (iii) P(X=15) =", ex2_iii, "\n\n")